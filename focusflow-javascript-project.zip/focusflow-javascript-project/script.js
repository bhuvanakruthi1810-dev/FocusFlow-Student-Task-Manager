const taskForm = document.querySelector("#taskForm");
const taskInput = document.querySelector("#taskInput");
const categoryInput = document.querySelector("#categoryInput");
const taskList = document.querySelector("#taskList");
const emptyState = document.querySelector("#emptyState");
const totalCount = document.querySelector("#totalCount");
const completedCount = document.querySelector("#completedCount");
const pendingCount = document.querySelector("#pendingCount");
const progressText = document.querySelector("#progressText");
const progressBar = document.querySelector("#progressBar");
const clearCompletedButton = document.querySelector("#clearCompleted");
const filterButtons = document.querySelectorAll(".filter");

let tasks = JSON.parse(localStorage.getItem("focusflow-tasks")) || [];
let currentFilter = "all";

document.querySelector("#todayLabel").textContent = new Date().toLocaleDateString("en-IN", {
  weekday: "short", month: "short", day: "numeric"
});

function saveTasks() {
  localStorage.setItem("focusflow-tasks", JSON.stringify(tasks));
}

function addTask(title, category) {
  const newTask = {
    id: Date.now() + Math.floor(Math.random() * 1000),
    title: title.trim(),
    category,
    completed: false
  };
  if (!newTask.title) return;
  tasks.unshift(newTask);
  saveTasks();
  renderTasks();
}

function toggleTask(id) {
  tasks = tasks.map(task =>
    task.id === id ? { ...task, completed: !task.completed } : task
  );
  saveTasks();
  renderTasks();
}

function deleteTask(id) {
  tasks = tasks.filter(task => task.id !== id);
  saveTasks();
  renderTasks();
}

function clearCompleted() {
  tasks = tasks.filter(task => !task.completed);
  saveTasks();
  renderTasks();
}

function createTaskElement(task) {
  const item = document.createElement("article");
  item.className = `task-item ${task.completed ? "done" : ""}`;

  const checkButton = document.createElement("button");
  checkButton.className = "check-btn";
  checkButton.type = "button";
  checkButton.setAttribute("aria-label", task.completed ? "Mark as not completed" : "Mark as completed");
  checkButton.innerHTML = task.completed ? "<span>✓</span>" : "";
  checkButton.addEventListener("click", () => toggleTask(task.id));

  const main = document.createElement("div");
  main.className = "task-main";

  const title = document.createElement("div");
  title.className = "task-title";
  title.textContent = task.title;

  const category = document.createElement("span");
  category.className = `category ${task.category}`;
  category.textContent = task.category;

  main.append(title, category);

  const deleteButton = document.createElement("button");
  deleteButton.className = "delete-btn";
  deleteButton.type = "button";
  deleteButton.setAttribute("aria-label", `Delete ${task.title}`);
  deleteButton.textContent = "×";
  deleteButton.addEventListener("click", () => deleteTask(task.id));

  item.append(checkButton, main, deleteButton);
  return item;
}

function renderTasks() {
  taskList.replaceChildren();

  const visibleTasks = tasks.filter(task => {
    if (currentFilter === "pending") return !task.completed;
    if (currentFilter === "completed") return task.completed;
    return true;
  });

  visibleTasks.forEach(task => taskList.appendChild(createTaskElement(task)));
  emptyState.hidden = visibleTasks.length > 0;
  taskList.hidden = visibleTasks.length === 0;

  const completed = tasks.filter(task => task.completed).length;
  const pending = tasks.length - completed;
  const progress = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;

  totalCount.textContent = tasks.length;
  completedCount.textContent = completed;
  pendingCount.textContent = pending;
  progressText.textContent = `${progress}%`;
  progressBar.style.width = `${progress}%`;

  filterButtons.forEach(button => {
    const active = button.dataset.filter === currentFilter;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
}

taskForm.addEventListener("submit", event => {
  event.preventDefault();
  addTask(taskInput.value, categoryInput.value);
  taskInput.value = "";
  taskInput.focus();
});

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    currentFilter = button.dataset.filter;
    renderTasks();
  });
});

clearCompletedButton.addEventListener("click", clearCompleted);

renderTasks();
