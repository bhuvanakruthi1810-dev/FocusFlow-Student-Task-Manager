# FocusFlow — Student Task Manager

A responsive task manager built with HTML, CSS, and vanilla JavaScript. It is inspired by the beginner JavaScript concepts covered in the reference course and turns them into a practical project.

## Features
- Add tasks with Study, Project, or Personal categories
- Mark tasks complete or incomplete
- Filter all, pending, and completed tasks
- Delete individual tasks or clear all completed tasks
- Live task statistics and completion progress bar
- Save tasks in browser `localStorage`
- Responsive layout for desktop and mobile

## Run the project
1. Download and unzip the project folder.
2. Open `index.html` in a modern browser.
3. Add a task to get started.

No installation or build tools are required.

## Concepts demonstrated
Variables (`let`/`const`), arrays, objects, functions, conditionals, array methods (`filter`, `map`, `forEach`), event listeners, DOM manipulation, template strings, JSON, and `localStorage`.

## Project structure
- `index.html` — page structure
- `style.css` — visual design and responsive layout
- `script.js` — task behavior and browser storage

## Note
Tasks are saved in the current browser on the current device. This demo does not use a server or account system.
